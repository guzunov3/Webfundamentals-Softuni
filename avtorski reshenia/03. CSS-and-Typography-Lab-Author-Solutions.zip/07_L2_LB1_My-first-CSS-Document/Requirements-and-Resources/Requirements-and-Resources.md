# 01 - My First CSS Document

### Constraints
 * Create **"index.html"** and **"style.css"** files
 * Change the **title** in the document
 * Use background with color - **rgb(51, 102, 153)**
 * Use white color for text