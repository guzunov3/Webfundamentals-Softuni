# 04 - Styling Tables

### Constraints
 * Create **"index.html"** and **"typography.css"** files
 * Change the **title** in the document
 * Create **table**
	* Use **thead** and **tbody** tags
	* Style the odd **td** tags with background: **rgb(241, 241, 241)**
